export default {
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: []
  }
};